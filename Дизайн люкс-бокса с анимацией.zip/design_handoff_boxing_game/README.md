# Handoff: 3D Boxing Game («Бокс-Империя»)

## Overview
A self-contained 3D boxing game built with Three.js. The player fights an AI opponent in a
broadcast-style gold ring. The match is won by landing **50 clean punches first**, by
**knockout** (referee counts to 10), or — if the 2:00 clock expires — **on points** (most clean
punches; equal = draw). Prize on the win screen is **$50,000**.

> **Important — this is NOT a UI mock.** Unlike a typical design handoff, `boxing.html` is a
> **complete, working game** (rendering, physics-ish movement, AI, combat, win logic, mobile
> controls all functional). You can run it as-is, extend it in place, or port the systems into
> another engine/codebase. The sections below document the architecture so it can be modified
> confidently in Claude Code.

## Fidelity
**High-fidelity & functional.** Final visuals, controls, and game rules are all implemented.
Treat the file as a working reference implementation, not a layout sketch.

## How to run
- Open `boxing.html` directly in any modern browser — **no build step, no install.**
- Single dependency, loaded from CDN: **Three.js r134** (`cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js`). For offline use, vendor this file locally and update the `<script src>`.
- Everything else (markup, CSS, all game code) lives inline in the one HTML file.

## Tech stack
- **Three.js r134**, `WebGLRenderer` (antialias, soft shadow maps, ACES filmic tone mapping, sRGB).
- One `<canvas id="c">` fills the viewport; HUD/overlay/touch controls are plain HTML+CSS layered on top with `z-index`.
- A single `requestAnimationFrame` loop (`loop()`) drives a fixed-ish `dt` (capped at 0.05s) and a smoothed `timeScale` for slow-motion.
- No frameworks, no bundler, no modules — all globals in one `<script>`.

---

## Controls

**Keyboard**
- `W A S D` / arrow keys — move anywhere in the ring (full 2D)
- `J` — jab (lead/left hand) · `L` — jab (rear/right hand)
- `K` — hook (heavy) · `Space` — block (hold) · `Shift` — dodge/slip

**Touch (mobile)** — shown automatically when a touch device is detected (`#touch` un-hidden)
- **Bottom-left:** white draggable **joystick** (`#joy` + `#joyKnob`) for movement, built on Pointer Events with `setPointerCapture`.
- **Bottom-right:** action buttons — `#bJabL`, `#bJabR`, `#bHook`, `#bBlock` (hold), `#bDodge`.
- Desktop with a fine pointer hides `#touch` via media query.

---

## Game rules & win conditions
Implemented in `update()` → checks in this order, then `knockdown()` / `endByPoints()`:
1. **Knockout** — a fighter's `stun` reaches **100** → `knockdown(youWin)`: opponent falls, referee walks in and counts **1→10** (720 ms per number), then `finishMatch()` declares KO.
2. **Race to 50** — first fighter to reach `LANDED_GOAL` (50) **clean** punches wins by points.
3. **Time up** — at `MATCH_TIME` (120 s) → `timeUp()` compares clean-punch counts: higher wins, equal = draw.

`stun` decays at **14/sec** (`f.stun -= 14*dt`), so the loser must be hit in quick succession to be dropped — single punches don't KO.

---

## Combat model (`resolveAttack(attacker, defender)`)
A punch "connects" at 45% through its animation (`progress >= 0.45`), once per throw (`didHit` flag). Then, by range (`Math.hypot` of the two fighters' `x,z`):
- **Reach:** jab `JAB_REACH = 1.8`, hook `HOOK_REACH = 2.0`.
- **Dodge active** (`D.dodge>0`) → clean miss, nothing happens.
- **Blocking** (`D.block`) → no count; sparks only; small stun (hook +4 / jab +2); camera shake.
- **Clean hit** → `A.landed++`; stun added = hook `26–36`, jab `10–15` (`const power = hook ? 26+rand*10 : 10+rand*5`); sets `hitFlash`, `knock`, `recoil`; spawns sparks; **blood** on heavy/finishing shots; camera shake.

Stamina: throwing costs stamina (jab 12, hook 22 in `tryAttack`); regenerates faster when not blocking. A fighter can't punch while blocking, dodging, mid-attack, or downed.

---

## Bot AI (`botAI(dt)`)
Tuned to be competitive (`aggression = 0.62`):
- **Modes:** `approach`, `retreat`, `strafe` (circling), `idle`; movement is continuous per mode each frame.
- **Reactive defense:** reads the player's punch early (during its first half) and sometimes blocks or slips; a slip sets a `counter` flag.
- **Counter-attack:** after a successful slip, fires back inside range.
- **Combinations:** throws 2–3 punch combos via a `combo` counter; mixes jabs and hooks.
- **Stamina management:** when `stamina < 22`, circles out / retreats to recover.
- Distance targets: closes when `dist > 2.0`, works in the pocket around `dist < 1.85`.

To make the bot easier/harder, adjust `aggression`, the reaction probability (`Math.random()<0.14`), combo frequency, and `power`/`stun` values.

---

## Scene & characters
- **Ring:** 12×12 canvas with a procedurally-drawn floor texture (gold concentric rings + `$` logo), gold apron skirt with trim, four corner posts + turnbuckles, three gold ropes per side.
- **Light rig:** overhead truss with emissive lamp housings and additive glow cones (purely visual — **no extra real lights**, kept off the renderer's light budget for shader-compile safety). Real lighting = 1 ambient + 1 directional (shadow caster) + 3 point lights.
- **Crowd:** four tiers built with two `InstancedMesh` (bodies + heads, ~270 each) plus ~48 additive **paparazzi flash** sprites that randomly pop.
- **Ambient gold dust:** 400-point `Points` system drifting upward.
- **Fighters (`makeBoxer`)** — anatomical, not capsules: tapered torso (V-taper, flattened front/back), neck, deltoids, head with jaw/ears/nose/eyes/hair/mouthguard, jointed arms (shoulder→upper→elbow→forearm→wrap→glove→thumb) and legs (hip→thigh→knee→shin→boot), gold championship belt. Player = blue trunks/gloves, bot = red.
- **Referee (`makeReferee`)** — striped shirt, dark trousers, raise-able arm for the count; hidden until a knockdown, then walks beside the downed fighter and chops the count.

## Animation (`animateBoxer(grp, f)`) — real boxing mechanics
Per-fighter smoothed state (`f._r`) lerped toward targets each frame:
- **Stance:** bladed orthodox guard (`BLADE = 0.5` shoulder turn), lead hand forward, rear heel raised.
- **Footwork:** bounce + alternating knee/hip bend while moving; subtle weight shift idle.
- **Jab:** lead hand fires straight, lead shoulder rolls to protect chin.
- **Cross (rear jab):** full hip+shoulder rotation, rear heel pivots over, lead hand guards.
- **Hook:** elbow locked ~90°, horizontal swing driven by torso rotation (`snap` curve).
- **Defense/reactions:** block crouch + high guard; slip (lean + head off-center); hit recoil (head + torso snap back); KO knockdown (collapse back, knees buckle).

## Effects
- **Sparks** (`burstSparks`) — 6 pooled additive `Points` bursts on every connect/block.
- **Blood** (`burstBlood`) — 5 pooled red `Points` bursts on heavy hits and knockdown; falls under gravity.
- **Camera shake** (`shakeAmt`, decays ×0.88/frame) on impacts.
- **Slow-motion** — `STATE.timeScaleTarget` eased into `timeScale`; drops to ~0.3 on knockdown, ~0.4 on a points finish.
- **KO camera** (`koCam`) — orbits the downed fighter during the count.

---

## Key tunable constants (top of the GAME STATE section)
| Constant | Value | Meaning |
|---|---|---|
| `TOTAL_PURSE` | `50000` | Prize shown on menu / win screen (`$50 000`) |
| `LANDED_GOAL` | `50` | Clean punches needed to win on points |
| `MATCH_TIME` | `120` | Round length in seconds (2:00) |
| `RING` | `4.5` | Half-extent of the movement area |
| `MIN_SEP` | `1.1` | Closest the two fighters can stand |
| `JAB_REACH` / `HOOK_REACH` | `1.8` / `2.0` | Hit ranges |
| `aggression` (in `botAI`) | `0.62` | Bot offense frequency / difficulty |
| stun per clean hit | hook `26–36`, jab `10–15` | KO pacing (KO at 100, decays 14/s) |

## Visual tokens
- **Gold palette:** `#ffcf5a`, `#fff6d8`, `#f5c84b`, `#9a6e1c`, `#fff7da`; the `.gold` text uses an animated shimmer gradient.
- **Player:** skin `#e8b48a`, trunks `#123a8a`, gloves `#2a6cff`, hair `#231812`.
- **Bot:** skin `#cf9b6f`, trunks `#7a1414`, gloves `#ff3030`, hair `#0a0a0a`.
- **Backgrounds:** scene `#07060c` with matching fog; overlay is a radial dark-gold vignette.
- **HUD fonts:** `'Trebuchet MS', system-ui, sans-serif`; tabular numerals for counters/timer.
- **UI element ids:** `#cntYou`/`#cntBot` (punch counters), `#stYou`/`#stBot` (stamina), `#timer`, `#round`, `#overlay`, `#koword`, `#count`/`#countNum`, `#joy`/`#joyKnob`, `#bJabL`/`#bJabR`/`#bHook`/`#bBlock`/`#bDodge`.

## Main code map (single file, top → bottom)
`renderer/scene/camera` setup → lights → procedural **textures** → **ring** → **referee** + **light rig** → **crowd** → gold **dust** → **sparks** → **blood** → `makeBoxer` / characters → **GAME STATE** + constants → **input** (keyboard) → **touch** (joystick + buttons) → `botAI` → `resolveAttack` → `animateBoxer` → `loop`/`update` → `knockdown`/`updateReferee`/`endByPoints`/`finishMatch` → `render` → `startGame`.

## Assets
None external. All textures (dollar/$ logo, glow, floor) are generated at runtime on `<canvas>`; all geometry is Three.js primitives. Only third-party file is Three.js r134 (CDN).

## Files
- `boxing.html` — the complete game (markup + CSS + JS inline).

## Suggested next steps for a developer
- Vendor Three.js locally for offline play.
- Split the inline script into ES modules (scene, characters, animation, AI, combat, ui) if integrating into a build.
- Add sound (punch/crowd/bell), a round system, and difficulty selection (drive off `aggression` + `power`).
- Replace primitive fighters with a rigged glTF model + animation clips if higher fidelity is needed.
